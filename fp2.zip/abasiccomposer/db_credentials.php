<?php
// Demonstrating the usage of it
// Following four lines set the details to establish a Database connection_aborted
DEFINE('DB_SERVER', 'localhost');
DEFINE('DB_NAME', 'merged_db');
DEFINE('DB_USER', 'root');
DEFINE('DB_PASS', '');

?>
