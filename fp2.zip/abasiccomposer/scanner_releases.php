<?php

  $nav_selected = "SCANNER"; 
  $left_buttons = "YES"; 
  $left_selected = "RELEASES"; 

  include("./nav.php");
  global $db;

  ?>


<div class="right-content">
    <div class="container">


      <h3 style = "color: #01B0F1;">Scanner -> System Releases</h3>

        <h3><img src="images/releases.png" style="max-height: 35px;" />System Releases</h3>

        <table id="info" cellpadding="0" cellspacing="0" border="0"
            class="datatable table table-striped table-bordered datatable-style table-hover"
            width="100%" style="width: 100px;">
          
       <br> <div id = " info_lenth" class = "database_filter"><button> Create </button></div></br>
              <thead>

                <tr id="table-first-row">
                  <th>id</th>
                  <th>Name</th>
                  <th>Type</th>
                  <th>Description</th>
                  <th>Address</th>
                  <th>City</th>
                  <th>State</th>
                  <th>Country</th>
                  <th>Email</th>
                  <th>Phone</th>
                  <th>Website</th>
                  <th>Creation_date</th>
                  <th>Last_update</th>
                  <th>Delete/Update</th>
                        
                </tr>
              </thead>

              <tfoot>
                <tr>
                  <th>Name</th>
                  <th>Type</th>
                  <th>Description</th>
                  <th>Address</th>
                  <th>City</th>
                  <th>State</th>
                  <th>Country</th>
                  <th>Email</th>
                  <th>Phone</th>
                  <th>Website</th>
                  <th>Creation_date</th>
                  <th>Last_update</th>
                  <th>Delete/Update</th>
                        
                </tr>

              </tfoot>

              <tbody>

              <?php

                $sql = "SELECT * FROM organization";
                $result = mysqli_query($db, $sql);

                if ($result->num_rows > 0) {
                  // Create table with data from each row
                  while($row = $result->fetch_assoc()) {
                    echo "<tr>
                    <td>" . $row["Name"]. "</td>
                    <td>" . $row["Type"]."</td>
                    <td>". $row["Description"]. "</td>
                    <td>" .$row["Address"]. "</td>
                    <td>" . $row["City"]."</td>
                    <td>" . $row["State"]. "</td>
                    <td>" . $row["Country"]. "</td>
                    <td>" . $row["Email"]. "</td>
                    <td>" . $row["Phone"]. "</td>
                    <td>" . $row["Website"]. "</td>
                    <td>" . $row["Creation_date"]. "</td>
                    <td>" . $row["Last_update"]. "</td>
                    
                      <form action='' method='POST'>
                        <input type='hidden' name='id' value='". $row["id"] . "'>
                        <input type='submit' id='admin_buttons' name='delete/update' value='Delete/Update'/>
                      </form>
                    </td>
                    </tr>";
                  }
                }
                ?>

              </tbody>
        </table>


        <script type="text/javascript" language="javascript">
    $(document).ready( function () {
        
        $('#info').DataTable( {
            dom: 'lfrtBip',
            buttons: [
                'copy', 'excel', 'csv', 'pdf'
            ] }
        );

        $('#info thead tr').clone(true).appendTo( '#info thead' );
        $('#info thead tr:eq(1) th').each( function (i) {
            var title = $(this).text();
            $(this).html( '<input type="text" placeholder="Search '+title+'" />' );
    
            $( 'input', this ).on( 'keyup change', function () {
                if ( table.column(i).search() !== this.value ) {
                    table
                        .column(i)
                        .search( this.value )
                        .draw();
                }
            } );
        } );
    
        var table = $('#info').DataTable( {
            orderCellsTop: true,
            fixedHeader: true,
            retrieve: true
        } );
        
    } );

</script>

        

 <style>
   tfoot {
     display: table-header-group;
   }
 </style>

  <?php include("./footer.php"); ?>
