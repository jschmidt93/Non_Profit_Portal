This "A Basic Composer" sample application provides some starer code to show menu options.
--> top level horiztonal menus
--> left hand side context specific menus

It also demonstrates JQUERY data table.