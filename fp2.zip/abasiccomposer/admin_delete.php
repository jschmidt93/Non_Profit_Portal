<?php

  $nav_selected = "SCANNER"; 
  $left_buttons = "YES"; 
  $left_selected = "RELEASES"; 

  include("./nav.php");
  global $db;

  ?>
<div>
$sql = "DELETE * from releases WHERE id = " .. $_POST['id'];
$result = $db->query($sql);
</div>